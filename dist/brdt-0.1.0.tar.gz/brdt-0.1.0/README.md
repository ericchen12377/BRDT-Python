# brdt
 Binomial Reliability Demonstration Tests, Python package
