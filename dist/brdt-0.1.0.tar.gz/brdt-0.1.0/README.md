# BRDT-Python
 Binomial Reliability Demonstration Tests, Python package
